// import axios from "axios";
// import { useEffect, useState, useSyncExternalStore } from "react";
// import "./App.css";

// function App(){
//   const [data, setData] =useState({
//     email : "",
//     password: "",
//     firstName: "",
//     lastName: "",
//     admin: false,
//   });
//   const [recipe, setRecipe] = useState([]);
//   const [recipeForm, setRecipeForm] = useState([]);
//   const handleForm = (e) =>
//   setData((prev) => ({ ...prev, [e.target.name]: e.target.value }));

//   const signupSubmit = async (e) => {
//     try {
//       e.preventDefault();
//       const res = await axios({
//         url: "http://localhost:3000/auth/signUp",
//         method: "post",
//         data: data,
//       });
//       window.alert(res.data.msg);
//     } catch (e) {
//       window.alert("ERROR");
//       console.error(e);
//     }
//   };
//   const loginSubmit = async (e) => {
//     try {
//       e.preventDefault();
//       const res = await axios({
//         url: "http://localhost:3000/auth/login",
//         method: "post",
//         data: data,
//       });
//       window.alert(res.data.msg);
//       if (res.data.token) setUser({ loggedIn: true, token: res.data.token });
//     } catch (e) {
//       window.alert("ERROR");
//       console.error(e);
//     }
//   };
//   return(
//     <div>

//     </div>
//   )
  
// }

// export default App;

import axios from "axios";
import { useState } from "react";
import "./App.css";

function App() {
  const [data, setData] = useState({
    email: "",
    password: "",
    firstName: "",
    lastName: "",
    admin: false,
  });
  const [recipeData, setRecipeData] = useState({
    name: "",
    ingredients: "",
    instructions: "",
  });


  const handleFormChange = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }));
  };

  const signupSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3000/auth/signUp", data);
      window.alert(res.data.msg);
    } catch (error) {
      console.error(error);
      window.alert("Error signing up.");
    }
  };

  const loginSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3000/auth/login", data);
      window.alert(res.data.msg);
      // Handle login success
    } catch (error) {
      console.error(error);
      window.alert("Error logging in.");
    }
  };
  const handleRecipeChange = (e) => {
    setRecipeData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }));
  };
  const addRecipeSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3000/recipes/addRecipe", recipeData);
      window.alert(res.data.msg);
      // Clear the form fields after successful submission
      setRecipeData({
        name: "",
        ingredients: "",
        method: "",
      });
    } catch (error) {
      console.error(error);
      window.alert("Error adding recipe.");
    }
  };
  
  return (
    <div className="App">
      <h2>Signup</h2>
      <form onSubmit={signupSubmit}>
        <label>Email:</label>
        <input
          type="email"
          name="email"
          value={data.email}
          onChange={handleFormChange}
          required
        />
        <label>Password:</label>
        <input
          type="password"
          name="password"
          value={data.password}
          onChange={handleFormChange}
          required
        />
        <label>First Name:</label>
        <input
          type="text"
          name="firstName"
          value={data.firstName}
          onChange={handleFormChange}
          required
        />
        <label>Last Name:</label>
        <input
          type="text"
          name="lastName"
          value={data.lastName}
          onChange={handleFormChange}
          required
        />
        <button type="submit">Sign Up</button>
      </form>

      <h2>Login</h2>
      <form onSubmit={loginSubmit}>
        <label>Email:</label>
        <input
          type="email"
          name="email"
          value={data.email}
          onChange={handleFormChange}
          required
        />
        <label>Password:</label>
        <input
          type="password"
          name="password"
          value={data.password}
          onChange={handleFormChange}
          required
        />
        <button type="submit">Login</button>
      </form>
      <h2>Add Recipe</h2>
      <form onSubmit={addRecipeSubmit}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={recipeData.name}
            onChange={handleRecipeChange}
            required
          />
        </div>
        <div>
          <label>Ingredients:</label>
          <textarea
            name="ingredients"
            value={recipeData.ingredients}
            onChange={handleRecipeChange}
            required
          ></textarea>
        </div>
        <div>
          <label>Instructions:</label>
          <textarea
            name="instructions"
            value={recipeData.instructions}
            onChange={handleRecipeChange}
            required
          ></textarea>
        </div>
        <button type="submit">Add Recipe</button>
      </form>
    </div>
   
  );
}

export default App;
